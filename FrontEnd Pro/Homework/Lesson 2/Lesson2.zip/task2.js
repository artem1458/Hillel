var type = typeof(parseInt(prompt('Введите число:')));
alert(type);