const person1 = {
  firstName: 'Peter',
  lastName: 'Kramer',
  age: 20,
};

const person2 = {
  firstName: 'Peter',
  lastName: 'Kramer',
  age: 30,
  fly: false,
};

function compareObjectsAndSwap(obj1, obj2) {
  const entriesFirst = Object.keys(obj1).map((item) => [item, obj1[item]]);
  const entriesSecond = Object.keys(obj2).map((item) => [item, obj2[item]]);

  const result = {};

  const filtered = entriesFirst.filter(([firstKey, firstValue]) => {
    return entriesSecond.find(([secondKey, secondValue]) => {
      return firstKey === secondKey && firstValue === secondValue;
    });
  });

  filtered.forEach(([key, value]) => Object.assign(result, { [value]: key }));

  return result;
}

console.log(compareObjectsAndSwap(person1, person2));
